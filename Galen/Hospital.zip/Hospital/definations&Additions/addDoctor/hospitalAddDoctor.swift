//
//  addDoctor.swift
//  Galen
//
//  Created by elfakharany on 4/23/19.
//  Copyright © 2019 Mohamed Elfakharany. All rights reserved.
//

import UIKit

class hospitalAddDoctor: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
